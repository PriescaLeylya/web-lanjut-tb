

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('PELANGGAN DATA DETAILS')); ?></div>

                <div class="card-body">
                    <table class="table table-responsive">
                        <tr><th>Nama</th><th>:</th><td><?php echo e($pelanggans->nama); ?></td></tr>
                        <tr><th>Jenis Kelamin</th><th>:</th><td> <?php echo e($pelanggans->jenis_kelamin); ?></td></tr>
                        <tr><th>Phone Number</th><th>:</th><td><?php echo e($pelanggans->phone_number); ?></td></tr>
                        <tr><th>Alamat</th><th>:</th><td><?php echo e($pelanggans->alamat); ?></td></tr>
                        <tr><th>Tujuan</th><th>:</th><td><?php echo e($pelanggans->tourtravels->Tujuan); ?></td></tr>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web lanjut\Project\resources\views/pelanggans/show.blade.php ENDPATH**/ ?>