 
<?php $__env->startSection('content'); ?> 
    <div class="container">
        <div class="row justify-content-center"> 
            <div class="col-md-8"> 
                <div class="card"> 
                    <div class="card-header"><?php echo e(__('PELANGGAN DATA')); ?></div> 

                    <div class="card-body"> 
                        <?php if(session('status')): ?> 
                            <div class="alert alert-success" role="alert"> 
                                <?php echo e(session('status')); ?> 
                            </div> 
                        <?php endif; ?> 

                        <form action="/pelanggans/<?php echo e($pelanggans->id); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="id" value="<?php echo e($pelanggans->id); ?>"></br>
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control" required="required" name="nama" value="<?php echo e($pelanggans->nama); ?>"></br>
                            </div>

                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                <input type="text" class="form-control" required="required" name="jenis_kelamin" value="<?php echo e($pelanggans->jenis_kelamin); ?>"></br>
                            </div>

                            <div class="form-group">
                                <label for="phone_number">Phone Number</label>
                                <input type="text" class="form-control" required="required" name="phone_number" value="<?php echo e($pelanggans->phone_number); ?>"></br>
                            </div>

                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" class="form-control" required="required" name="alamat" value="<?php echo e($pelanggans->alamat); ?>"></br>
                            </div>

                            <button type="submit" name="edit" class="btn btn-primary float-right">Save Changes</button>
                        </form>
                    </div> 
                </div> 
            </div> 
        </div> 
    </div> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web lanjut\Project\resources\views/pelanggans/edit.blade.php ENDPATH**/ ?>