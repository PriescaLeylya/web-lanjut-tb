 
<?php $__env->startSection('content'); ?> 
    <div class="container">
        <div class="row justify-content-center"> 
            <div class="col-md-8"> 
                <div class="card"> 
                    <div class="card-header"><?php echo e(__('PAKET TOUR DATA')); ?></div> 

                    <div class="card-body"> 
                        <?php if(session('status')): ?> 
                            <div class="alert alert-success" role="alert"> 
                                <?php echo e(session('status')); ?> 
                            </div> 
                        <?php endif; ?> 

                        <center><img src="<?php echo e(asset('storage/'.$tourtravels->photo)); ?>" width='300px'></center>

                        <form action="/tourtravels/<?php echo e($tourtravels->id); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="id" value="<?php echo e($tourtravels->id); ?>"></br>
                            <div class="form-group">
                                <label for="Tujuan">Tujuan</label>
                                <input type="text" class="form-control" required="required" name="Tujuan" value="<?php echo e($tourtravels->Tujuan); ?>"></br>
                            </div>

                            <div class="form-group">
                                <label for="Destinasi">Destinasi</label>
                                <input type="text" class="form-control" required="required" name="Destinasi" value="<?php echo e($tourtravels->Destinasi); ?>"></br>
                            </div>

                            <div class="form-group">
                                <label for="Harga">Harga</label>
                                <input type="text" class="form-control" required="required" name="Harga" value="<?php echo e($tourtravels->Harga); ?>"></br>
                            </div>
                            <button type="submit" name="edit" class="btn btn-primary float-right">Submit</button>
                        </form>
                    </div> 
                </div> 
            </div> 
        </div> 
    </div> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web lanjut\Project\resources\views/tourtravels/edit.blade.php ENDPATH**/ ?>