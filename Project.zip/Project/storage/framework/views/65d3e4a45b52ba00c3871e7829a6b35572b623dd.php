 
<?php $__env->startSection('content'); ?> 
    <div class="container">
        <div class="row justify-content-center"> 
            <div class="col-md-8"> 
                <div class="card"> 
                    <div class="card-header"><?php echo e(__('PELANGGAN DATA')); ?></div> 

                    <div class="card-body"> 
                        <?php if(session('status')): ?> 
                            <div class="alert alert-success" role="alert"> 
                                <?php echo e(session('status')); ?> 
                            </div> 
                        <?php endif; ?> 
                        
                        <form action="/pelanggans" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="nama">Name</label>
                                <input type="text" class="form-control" required="required" name="nama"></br>
                            </div>

                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                <input type="text" class="form-control" required="required" name="jenis_kelamin"></br>
                            </div>

                            <div class="form-group">
                                <label for="phone_number">Phone Number</label>
                                <input type="text" class="form-control" required="required" name="phone_number"></br>
                            </div>

                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" class="form-control" required="required" name="alamat"></br>
                            </div>
                            <div class="form-group">
                                <label for="Tujuan">Tujuan</label>
                                <select class="form-control" name="Tujuan">
                                    <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s->id); ?>"> 
                                    <?php echo e($s->Tujuan); ?> 
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select></br>
                            </div>                       
                            <button type="submit" name="add" class="btn btn-primary float-right">Simpan</button>
                            <button type="submit" name="add" class="btn btn-primary float-right">Print PDF</button>
                            <a href="/pelanggan/<?php echo e($pelanggans->id); ?>/report" class="btn btn-primary" target="_blank">PRINT PDF</a>

                            
                        </form> 
                    </div> 
                </div> 
            </div> 
        </div> 
    </div> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web lanjut\Project\resources\views/pelanggans/create.blade.php ENDPATH**/ ?>