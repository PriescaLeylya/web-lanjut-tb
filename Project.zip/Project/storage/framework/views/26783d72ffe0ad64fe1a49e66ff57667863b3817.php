

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="card">
            <br><br>

                <div class="card-header"><?php echo e(__(' DATA TOURTRAVEL')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <!--Search-->
                    <form class="form" method="get" action="<?php echo e(route('search')); ?>">
                            <div class="form-group w-100 mb-3">
                                <input type="text" name="search" class="form-control w-75 d-inline" id="search" placeholder="search...">
                                <button type="submit" class="btn btn-primary mb-1">Search</button>
                            </div>
                    </form>
                <a href="/tourtravels/create" class="btn btn-primary">Add Data</a>
              
             
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Tujuan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tourtravels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(asset('storage/'.$s->photo)); ?>" width='120px'></td>
                        <td><?php echo e($s->Tujuan); ?></td>
                        <td>
                        <form action="/tourtravels/<?php echo e($s->id); ?>" method="post">
                        <a href="/tourtravels/<?php echo e($s->id); ?>" class="btn btn-info">View</a>
                        <a href="/tourtravels/<?php echo e($s->id); ?>/edit" class="btn btn-primary">Edit</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                         <button type="submit" name="delete" class="btn btn-danger">Delete</button>    
                         </form>       
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web lanjut\Project\resources\views/tourtravels/index.blade.php ENDPATH**/ ?>