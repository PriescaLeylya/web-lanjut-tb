

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('TOURTRAVEL DATA DETAILS')); ?></div>

                <div class="card-body">
                    <table class="table table-responsive">
                        <center><img src="<?php echo e(asset('storage/' .$tourtravels->photo)); ?>" width='200px'></center>
                        <br>
                        <tr><th>Tujuan</th><th>:</th><td><?php echo e($tourtravels->Tujuan); ?></td></tr>
                        <tr><th>Destinasi</th><th>:</th><td><?php echo e($tourtravels->Destinasi); ?></td></tr>
                        <tr><th>Harga</th><th>:</th><td> <?php echo e($tourtravels->Harga); ?></td></tr>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web lanjut\Project\resources\views/tourtravels/show.blade.php ENDPATH**/ ?>