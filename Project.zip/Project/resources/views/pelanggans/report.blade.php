<!DOCTYPE html>
        <html>
        <head>
        <title>Membuat Laporan PDF Dengan DOMPDF Laravel</title>
        </head>
        <body>
        <style type="text/css">
        table tr td,
        table tr th{
        font-size: 9pt;
        }
        </style>
        <h4 align="center">PELANGGAN REPORT</h4>
        <b>Name</b> : {{ $pelanggan>name }} <br>
        <b>Jenis_Kelamin</b> : {{ $pelanggan->Jenis_Kelamin }} <br>
        <b>Phone_Number</b> : {{ $pelanggan->Phone_Number }} <br><br>
        <b>Alamat</b> : {{ $pelanggan->Alamat }} <br>
        <b>Tujuan</b> : {{ $pelanggan->Tujuan }} <br><br>
        <table class="table table-responsive table-striped">
        <thead>
        <tr>
        <th>Name</th> 
        <th>Jenis_Kelamin</th>
        <th>Phone_Number</th>
        <th>Alamat </th>
        <th>Tujuan </th>
        </tr>
        </thead>
        <tbody>
        @foreach ($pelanggan->courses as $sc)
        <tr>
        <td>{{ $sc->Name}}</td>
        <td>{{ $sc->Jenis_Kelamin }}</td>
        <td>{{ $sc->Phone_Number }}</td>
        <td>{{ $sc->Alamat }}</td>
        <td>{{$sc->Tujuan}}</td>
        </tr>
        @endforeach
        </tbody>
        </table>
        </body>
</html>