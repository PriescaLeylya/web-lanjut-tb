<html>
    <head>
        <title>Article</title>
    </head>
    <body>
        <h1>Halaman Article</h1>
        <p>Article index ke-<?php echo e($id); ?></p>
        <?php echo e($article); ?>

    </body>
</html><?php /**PATH C:\web lanjut\minggu4\resources\views/article.blade.php ENDPATH**/ ?>