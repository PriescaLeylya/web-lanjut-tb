<html>
    <head>
        <title>Home</title>
    </head>
    <body>
        <h1>Halaman Home</h1>
        <?php echo e($article); ?>

    </body>
</html><?php /**PATH C:\web lanjut\minggu4\resources\views/home.blade.php ENDPATH**/ ?>