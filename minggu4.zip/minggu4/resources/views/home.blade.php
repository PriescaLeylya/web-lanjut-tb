<html>
    <head>
        <title>Home</title>
    </head>
    <body>
        <h1>Halaman Home</h1>
        {{$article}}
    </body>
</html>