<html>
    <head>
        <title>Article</title>
    </head>
    <body>
        <h1>Halaman Article</h1>
        <p>Article index ke-{{$id}}</p>
        {{$article}}
    </body>
</html>